import { Injectable } from '@angular/core';
import { IProduct } from '../product-list/product';
import { range, Observable, of, throwError } from 'rxjs';
import { map, filter, delay, tap, catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ProductService {

    constructor(private http: HttpClient) {}

    getNumbers(): Observable<number> {
        /* const nums$ = range(0, 10).pipe(
            filter(x => x % 2 === 0),
            map(x => x * 10)
        ); */

        const nums$ = of(1, 5, 8, 30).pipe(
            filter(x => x % 2 === 0),
            map(x => x * 10)
        );

        // const nums$ = of([1, 3, 5, 8]);

        return nums$;
    }

    getProducts(): Observable<IProduct[]> {
        return this.http.get<IProduct[]>(environment.apiUrl + 'assets/products.json')
            .pipe(
                delay(1000),
                tap(products => console.log(products)),
                catchError(this.handleError)
            );
    }

    handleError(err) {
        let errorMessage = '';
        if (err.error instanceof HttpResponse) {
            // client-side error
            errorMessage = err.error.message;
        } else {
            // server-side error
            errorMessage = `${err.status}: ${err.message}`;
        }
        return throwError(errorMessage);
    }
}
