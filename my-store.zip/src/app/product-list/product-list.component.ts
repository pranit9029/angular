import { Component, OnInit, OnDestroy } from '@angular/core';
import { IProduct } from './product';
import { ProductService } from '../services/product.service';
import { Subscription, Subject } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit, OnDestroy {
  pageTitle = 'Product List';
  imageWidth = 100;

  headerClasses = {
    'theader-bg': true,
    'theader-fg': true
  };

  showImage = false;

  filteredProducts: IProduct[];
  products: IProduct[];

  private unsubscribe$: Subject<any> = new Subject<any>();

  private _filterBy: string;

  get filterBy(): string {
    return this._filterBy;
  }

  set filterBy(fb: string) {
    this._filterBy = fb;
    this.filteredProducts = this.products.filter(product => {
      return product.name.toLowerCase().indexOf(fb.toLowerCase()) !== -1;
    });
  }

  constructor(private productService: ProductService) {
    console.log('Constructor');
  }

  ngOnInit(): void {
    this.productService.getProducts()
      .pipe(
        takeUntil(this.unsubscribe$)
      )
      .subscribe(products => {
        this.products = products; // .filter(product => product.featured);
        this.filteredProducts = this.products;
      }, error => console.log(error));

    this.productService.getNumbers().subscribe(num => console.log(num));
  }

  toggleImage(): void {
    this.showImage = !this.showImage;
  }

  onRating(msg: string): void {
    this.pageTitle = msg;
  }

  ngOnDestroy(): void {
    this.unsubscribe$.unsubscribe();
  }

}
