export interface IProduct {
    id: number;
    name: string;
    description: string;
    price: number;
    code: string;
    rating: number;
    date: number;
    featured: boolean;
    imageUrl: string;
}
