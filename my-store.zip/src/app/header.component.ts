import { Component } from '@angular/core';

@Component({
    selector: 'app-header',
    template: '<h1><span class="fa fa-home"></span> {{title}}</h1>',
    styles: [
        `
        h1 {
            font-style: italic;
        }
        `
    ]
})
export class HeaderComponent {
    title = 'My Store';
}
