import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ConvertToSpace } from './shared/convert-to-space.pipe';
import { StarComponent } from './shared/star/star.component';
import { HighlightDirective } from './shared/highlight.directive';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './services/token-interceptor';

@NgModule({
  imports: [
    BrowserModule,    // import all dependent modules
    FormsModule,
    HttpClientModule
  ],
  declarations: [    // all components, pipes and directives should be declared inside this array
    AppComponent,
    HeaderComponent,
    ProductListComponent,
    ConvertToSpace,
    StarComponent,
    HighlightDirective
  ],
  exports: [],       // export all components, pipes and directives which will be used by other modules
  bootstrap: [       // bootstrap components
    AppComponent
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true }
  ]
})
export class AppModule { }
